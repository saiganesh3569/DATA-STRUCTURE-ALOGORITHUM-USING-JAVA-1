
public class BinaryTreeToDLL {
	 static class node {
		  
	        int data;
	        node left;
	        node right;
	    };

	    static node head, tail;
	    static void bintree2listUtil(node root)
	    {
	        if (root == null)
	            return;
	  
	        node left = root.left;
	        node right = root.right;
	  
	        bintree2listUtil(root.left);
	  
	        if (head == null) {
	            head = root;
	        }
	  
	        root.left = tail;
	  
	        if (tail != null) {
	            (tail).right = root;
	        }
	        tail = root;
	        
	        bintree2listUtil(root.right);
	    }
	    static void bintree2list(node root)
	    {
	        if (root == null)
	            head = root;
	        bintree2listUtil(root);
	    }
	    static node newNode(int data)
	    {
	        node new_node = new node();
	        new_node.data = data;
	        new_node.left = new_node.right = null;
	        return (new_node);
	    }
	    static void printList()
	    {
	    	 while (head != null) {
	             System.out.print(head.data + " ");
	             head = head.right;
	         }
	     }
	     public static void main(String[] args)
	     {
	         node root = newNode(10);
	         root.left = newNode(12);
	         root.right = newNode(15);
	         root.left.left = newNode(25);
	         root.left.right = newNode(30);
	         root.right.left = newNode(36);
	         head = null;
	         tail = null;
	         bintree2list(root);
	         printList();
	     }
	    }

