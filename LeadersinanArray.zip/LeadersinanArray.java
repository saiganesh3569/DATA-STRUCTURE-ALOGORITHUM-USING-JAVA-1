
public class LeadersinanArray {
	 void printLeaders(int arr[], int size) 
	    {
	        for (int i = 0; i < size; i++) 
	        {
	            int j;
	            for (j = i + 1; j < size; j++) 
	            {
	                if (arr[i] <=arr[j])
	                    break;
	            }
	            if (j == size) 
	                System.out.print(arr[i] + " ");
	        }
	    }
	    public static void main(String[] args) 
	    {
	    	LeadersinanArray lead = new LeadersinanArray();
	        int arr[] = new int[]{1, 2, 3, 4, 0};
	        int n = arr.length;
	        lead.printLeaders(arr, n);
	    }
}
